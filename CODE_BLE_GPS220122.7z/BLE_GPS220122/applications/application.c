/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 * 2013-07-12     aozima       update for auto initial.
 */

/**
 * @addtogroup STM32
 */
/*@{*/

#include <board.h>
#include <rtthread.h>
#include <string.h>
#include "flash.h"

//#include "led.h"
#include <rtdevice.h>

#ifdef  RT_USING_COMPONENTS_INIT
#include <components.h>
#endif  /* RT_USING_COMPONENTS_INIT */


#ifdef RT_USING_STM32_USB_VCP
	int rt_hw_vcp_init(void); 
#endif

rt_device_t dev_gps = RT_NULL;
rt_device_t dev_ble = RT_NULL;
rt_device_t dev_usb = RT_NULL;
rt_timer_t adc_timer;
	
char buf[260] ;






void rt_init_thread_entry(void* parameter)
{
	rt_uint32_t ret;
	

	
	#ifdef RT_USING_COMPONENTS_INIT
		rt_components_init();
	#endif
	rt_console_set_device(RT_USB_VCP_DEVICE);
	#ifdef RT_USING_STM32_USB_VCP 
		rt_console_set_device(RT_CONSOLE_DEVICE_NAME);
	#else
		rt_console_set_device(RT_USB_VCP_DEVICE);
	#endif
	dev_usb = rt_device_find("usbvcp");
	if(dev_usb != RT_NULL){
		rt_device_open(dev_usb, RT_DEVICE_OFLAG_RDWR | RT_DEVICE_FLAG_INT_RX) ;
		rt_console_set_device("usbvcp");
	}
	dev_gps = rt_device_find("uart2");
	rt_device_open(dev_gps, RT_DEVICE_OFLAG_RDWR | RT_DEVICE_FLAG_INT_RX) ;
	dev_ble = rt_device_find("uart3");
	rt_device_open(dev_ble, RT_DEVICE_OFLAG_RDWR | RT_DEVICE_FLAG_INT_RX) ;
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	sleep(100);
	
	while(1){
			ret = rt_device_read(dev_gps,0,buf,256);//GPS����ת����USB��BLE
			if(ret){
				rt_device_write(dev_usb,0,buf,ret);
				rt_device_write(dev_ble,0,buf,ret);
			}
			ret = rt_device_read(dev_usb,0,buf,256);//USB�յ�����͸����GPS
			if(ret){
				rt_device_write(dev_gps,0,buf,ret);
				rt_device_write(dev_ble,0,buf,ret);
			}
			ret = rt_device_read(dev_ble,0,buf,256);//BLE�յ����ݴ�������
			if(ret){
				rt_device_write(dev_usb,0,buf,ret);
			    rt_device_write(dev_gps,0,buf,ret);
			}
		sleep(30);
	}
}

int rt_application_init(void)
{
    rt_thread_t tid;
	
    tid = rt_thread_create("init",rt_init_thread_entry, RT_NULL,1024, 19, 20);
    if (tid != RT_NULL)
        rt_thread_startup(tid);
    
    return 0;
}


/*@}*/
