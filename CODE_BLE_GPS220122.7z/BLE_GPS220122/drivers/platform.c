/*************************************************************************
* File Name:    platform.c
* create by:    doucheng
* Date First Issued :   2014-06-15
* Description       :   This file contains the c code of cellular moduler
*                       flexible for three cellular device
* modified by doucheng
* date: 2014/06/15
* ver: v 0.1
*
**************************************************************************/
#include <rtthread.h>
#include "board.h"
#include "platform.h"

#ifdef RT_USING_FINSH
#include "shell.h"
#endif

int hw_Io_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		
	GPIO_InitStructure.GPIO_Pin   = USB_EN_PIN ;
	GPIO_Init(USB_EN_GPIO,&GPIO_InitStructure) ;
	
	GPIO_InitStructure.GPIO_Pin   = BT_EN_PIN ;
	GPIO_Init(BT_EN_GPIO,&GPIO_InitStructure) ;

	BT_ON;
	USB_DIS;
	return RT_EOK ;
}









