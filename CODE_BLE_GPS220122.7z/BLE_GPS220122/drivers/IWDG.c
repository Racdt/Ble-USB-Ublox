#include <board.h>
#include <platform.h>
struct rt_event	iwdg_timeout_event;
int IWDG_Init(void)
{
	#if  IWGD 
		IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable); /* Enable write access to IWDG_PR and IWDG_RLR registers */ 
		IWDG_SetPrescaler(IWDG_Prescaler_256); /* IWDG counter clock: 40KHz(LSI) / 256 = 156Hz  6.4 ms*/
		IWDG_SetReload(4095); /* Set counter reload value to  */ 
		IWDG_ReloadCounter(); /* Reload IWDG counter */ 
		IWDG_Enable(); /* Enable IWDG (the LSI oscillator will be enabled by hardware) */ 
		rt_event_init(&iwdg_timeout_event,"ev_iwdg",RT_IPC_FLAG_FIFO);
	#endif
	return RT_EOK ;
}

#if  IWGD 
	INIT_BOARD_EXPORT(IWDG_Init);
#endif

void Feed_Dog(void)
{
	#if  IWGD 
		rt_uint32_t event = 0  ;	
		if (rt_event_recv(&iwdg_timeout_event,EV_IWDG_ALL,RT_EVENT_FLAG_AND |RT_EVENT_FLAG_CLEAR,0, &event) == RT_EOK ){
			BKP_WriteBackupRegister(BKP_DR8,event);
			IWDG_ReloadCounter(); 
		}
		else{
			rt_event_recv(&iwdg_timeout_event,EV_IWDG_ALL,RT_EVENT_FLAG_OR,0, &event) ;
			BKP_WriteBackupRegister(BKP_DR8,event);
		}
	#endif	
}


