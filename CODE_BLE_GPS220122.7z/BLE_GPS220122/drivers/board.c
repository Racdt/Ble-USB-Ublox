/*
 * File      : board.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009 RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      first implementation
 * 2013-07-12     aozima       update for auto initial.
 */

#include <rthw.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "stm32f10x.h"
#include "stm32f10x_fsmc.h"
#include "board.h"
#include "usart.h"
#ifdef RT_USING_CAN
#include "bxcan.h"
#endif
#ifdef  RT_USING_COMPONENTS_INIT
#include <components.h>
#endif  /* RT_USING_COMPONENTS_INIT */

#ifdef RT_USING_DFS
/* dfs filesystem:ELM filesystem init */
#include <dfs_elm.h>
/* dfs Filesystem APIs */
#include <dfs_fs.h>
#endif

#ifdef RT_USING_RTC
	#include "rtc.h"
#endif


#include "platform.h"
/**
 * @addtogroup STM32
 */

/*@{*/


/**
 * This is the timer interrupt service routine.
 *
 */
void SysTick_Handler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    rt_tick_increase();

    /* leave interrupt */
    rt_interrupt_leave();
}

RCC_ClocksTypeDef  RCC_CLK ;
/**
 * This function will initial STM32 board.
 */
void rt_hw_board_init(void)
{
    #ifdef  VECT_TAB_RAM
		/* Set the Vector Table base location at 0x20000000 */
		NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
	#else  /* VECT_TAB_FLASH  */
		/* Set the Vector Table base location at 0x08000000 */
		NVIC_SetVectorTable(NVIC_VectTab_FLASH, APP_ADD);
	#endif
	RCC_GetClocksFreq(&RCC_CLK) ;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
    /* Configure the SysTick */
    SysTick_Config( RCC_CLK.SYSCLK_Frequency / RT_TICK_PER_SECOND );

	#if STM32_EXT_SRAM
		EXT_SRAM_Configuration();
	#endif

   rt_hw_usart_init();

	#ifdef RT_USING_COMPONENTS_INIT
		rt_components_board_init();
	#endif
}

/*@}*/
