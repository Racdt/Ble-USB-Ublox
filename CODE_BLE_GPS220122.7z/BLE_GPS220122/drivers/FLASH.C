
#include <board.h>
#include <rtthread.h>
#include <string.h>
#include "flash.h"

#include <rtdevice.h>
u32 EraseCounter = 0x00 , Address = 0x00;
u32 NbrOfPage = 1;



void write_flash(u32 addr , u32 *buf , u32 Length )
{
	u32 x = 0 ;
	FLASH_Status FLASHStatus;
	FLASHStatus = FLASH_COMPLETE;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);	
	for(EraseCounter = 0; (EraseCounter < 1) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
    	FLASHStatus = FLASH_ErasePage(addr + (FLASH_PAGE_SIZE * EraseCounter));
	Address = addr;
	while(FLASHStatus == FLASH_COMPLETE)
		{
			if( ( FLASH_ProgramWord(Address, buf[x]) ) == FLASH_COMPLETE )
				{
					Address+=4 ;
					x++ ;
				}
			if(x == Length)
				break ;
		}
	FLASH_Lock();
}  

