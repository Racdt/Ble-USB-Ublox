/*
 * File      : usart.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

#ifndef __USART_H__
#define __USART_H__

#include <rthw.h>
#include <rtthread.h>
//#define UART3_REMAP

#define UART_ENABLE_IRQ(n)            NVIC_EnableIRQ((n))
#define UART_DISABLE_IRQ(n)           NVIC_DisableIRQ((n))

/* USART1 */
#define UART1_GPIO_TX       GPIO_Pin_9
#define UART1_GPIO_RX       GPIO_Pin_10
#define UART1_GPIO          GPIOA

//#define UART2_REMAP
/* USART2 */
#define UART2_GPIO_TX       GPIO_Pin_2
#define UART2_GPIO_RX       GPIO_Pin_3
#define UART2_GPIO          GPIOA

/* USART3_REMAP[1:0] = 00 */

#ifdef UART3_REMAP
	#define UART3_GPIO_TX       GPIO_Pin_8
	#define UART3_GPIO_RX       GPIO_Pin_9
	#define UART3_GPIO          GPIOD
#else
	#define UART3_GPIO_TX       GPIO_Pin_10
	#define UART3_GPIO_RX       GPIO_Pin_11
	#define UART3_GPIO          GPIOB
#endif

/* USART4 */
#define UART4_GPIO_TX       GPIO_Pin_10
#define UART4_GPIO_RX       GPIO_Pin_11
#define UART4_GPIO          GPIOC

/* USART4 */
#define UART5_GPIO_TX       GPIO_Pin_12
#define UART5_GPIO_RX       GPIO_Pin_2
#define UART5TX_GPIO          GPIOC
#define UART5RX_GPIO          GPIOD
/* STM32 uart driver */

void rt_hw_usart_init(void);

#endif
