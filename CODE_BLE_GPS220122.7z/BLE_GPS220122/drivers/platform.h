
/*
 * File      : board.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-09-22     Bernard      add board.h to this bsp
 */

// <<< Use Configuration Wizard in Context Menu >>>
#ifndef __platform_H__
#define __platform_H__
#include <rtdef.h>
#include <rtthread.h>
#include <stm32f10x.h>

#define  sleep    rt_thread_delay


#define USB_EN_PIN     			GPIO_Pin_15
#define USB_EN_PORT    		RCC_APB2Periph_GPIOA
#define USB_EN_GPIO    		GPIOA
 
#define BT_EN_PIN     				GPIO_Pin_1
#define BT_EN_PORT    			RCC_APB2Periph_GPIOA
#define BT_EN_GPIO    			GPIOA
         

#define BT_ON							GPIO_SetBits(BT_EN_GPIO,BT_EN_PIN)  
#define BT_OFF						GPIO_ResetBits(BT_EN_GPIO,BT_EN_PIN)  

#define USB_EN						GPIO_SetBits(USB_EN_GPIO,USB_EN_PIN)  
#define USB_DIS						GPIO_ResetBits(USB_EN_GPIO,USB_EN_PIN)  


extern RCC_ClocksTypeDef  RCC_CLK ;

#endif 


