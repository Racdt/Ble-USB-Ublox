#ifndef __flash_h
#define __flash_h

#define StartAddr  ((u32)0x800fc00)
#define EndAddr    ((u32)0x8001000)

#define FLASH_PAGE_SIZE    ((u16)0x400)

void write_flash(u32 addr, u32 *buf , u32 Length );

#endif
